#!/bin/bash

HELP=0
EFICOMPRESSNAME="EfiCompress.macosx"

for i in $*
do
	case $i in
    	--romfile=*)
		ROMFILE=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
		;;
    	--efifile=*)
		EFIFILE=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
		;;
    	--devid=*)
		DEVID=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
		;;
    	--originalrom=*)
		ORIGROM=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
		;;
    	--help)
		HELP=1
		;;
    	*)
		HELP=1
		;;
  	esac
done

if [[ "$HELP" == 1 ]];
then
    echo "Example: $0 --efifile=7950mac.efi --romfile=efiromheader.rom --originalrom=7950.rom --devid=6783"
    exit -1
fi

echo "running on $EFIFILE, $ROMFILE with devid $DEVID"

java PatchRom $EFIFILE $ROMFILE $DEVID

if [ -a $EFICOMPRESSNAME ]
then
    $PWD/$EFICOMPRESSNAME $EFIFILE $EFIFILE.comp
else
    echo "$EFICOMPRESSNAME is missing, aborting"
    exit -1
fi

cp $ROMFILE $DEVID.efipart.rom
dd if=$EFIFILE.comp of=$DEVID.efipart.rom bs=1 seek=$((0x160)) conv=notrunc

echo "EFI part is ready at $DEVID.efipart.rom"

size=`java getSize $ORIGROM`

echo "orig size - $size"

EFIROM="$ORIGROM.efi.rom"

cp $ORIGROM $EFIROM

dd if=$DEVID.efipart.rom of=$EFIROM bs=1 seek=$size conv=notrunc

rm $DEVID.efipart.rom $EFIFILE.comp

python fixrom.py $EFIROM $EFIROM

echo "the rom is ready at $EFIROM"